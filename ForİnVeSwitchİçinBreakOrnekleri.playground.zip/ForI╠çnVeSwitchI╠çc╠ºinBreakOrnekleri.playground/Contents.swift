import UIKit

for i in 1...5 {
    if i == 3 {
        break
    }
    print ("Döngü 5 :\(i)")
}





for i in 1...5 {
    if i == 3 {
        continue

    }
    print ("Döngü 6 :\(i)")
}
